package org.example.model;

public class Mobil {
    String nev;
    String gyarto;
    boolean esim;

    public String getNev() {
        return nev;
    }

    public void setNev(String nev) {
        this.nev = nev;
    }

    public String getGyarto() {
        return gyarto;
    }

    public void setGyarto(String gyarto) {
        this.gyarto = gyarto;
    }

    public boolean isEsim() {
        return esim;
    }

    public void setEsim(boolean esim) {
        this.esim = esim;
    }
}
